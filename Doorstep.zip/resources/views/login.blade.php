@extends('layouts.master')

@section('title', 'Door Step | Login')

@section('inner-content')

{{-- Inner Page Content Comes here --}}
<section id="or-login" class="or-login-section" style="background: #76a713">
    <div class="or-login-content sign-login-area d-flex justify-content-center align-items-center">
        <div class="or-login-form">
            <form>
                <input type="email" name="email" placeholder="Your Email" required="">
                <input type="password" name="password" placeholder="Your Password" required="">
                <div class="login-button text-center">
                    {{-- <button>Sign In</button> --}}
                    <button type="submit" value="Login">Login</button>
                </div>
                <div class="col text-center text-white mt-3 ">
                    <p>Forgot Password? <a href="/resetpassword">Reset Password Here</a></p>
                </div>
            </form>
        </div>
    </div>
</section>

@endsection

@section('loginscript')

<script>
    $(document).ready(function() {
        console.log($.session.get('user'))
        if ($.session.get('user')) {
            $('#login').hide();
            $('#register').hide();

        } else {
            $('#profile').hide();
            $('#logout').hide();
            //$('#groceries').hide();
        }
    });
</script>

@endsection
