<!-- Start of Footer  section
	============================================= -->
	<section id="or-footer-3" class="or-footer-section-3" data-background="assets/img/bg/h5-bg-footer.jpg">
		<div class="container">
			<div class="footer-widget-wrapper-3">
				<div class="row">
					<div class="col-lg-3 col-md-6">
						<div class="or-footer-widget headline pera-content ul-li-block">
							<div class="or-logo-widget">
								<a href="#"><img src="assets/img/logo/logo2.png" alt=""></a>
								<p>We work with a passion of taking challenges and creating new ones in advertising sector.	</p>
								<div class="footer-social">
									<a href="#" tabindex="0"><i class="fab fa-facebook-f"></i></a>
									<a href="#" tabindex="0"><i class="fab fa-twitter"></i></a>
									<a href="#" tabindex="0"><i class="fab fa-dribbble"></i></a>
									<a href="#" tabindex="0"><i class="fab fa-behance"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="or-footer-widget  headline-2 pera-content ul-li-block">
							<div class="or-menu-widget">
								<h2 class="widget-title">Information</h2>
								<ul>
									<li><a href="#">Specials</a></li>
									<li><a href="#">Wishlist</a></li>
									<li><a href="#">Compare</a></li>
									<li><a href="#">Our stores</a></li>
									<li><a href="#">Contacts us</a></li>
									<li><a href="#">About us</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="or-footer-widget  headline-2 pera-content ul-li-block">
							<div class="or-menu-widget">
								<h2 class="widget-title">Categories</h2>
								<ul>
									<li><a href="#">Bread & Bakery</a></li>
									<li><a href="#">Fresh Fruits</a></li>
									<li><a href="#">Fresh Fish</a></li>
									<li><a href="#">Fresh Meat</a></li>
									<li><a href="#">Grocery & Frozen</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6">
						<div class="or-footer-widget  headline-2 pera-content ul-li-block">
							<div class="or-menu-widget">
								<h2 class="widget-title">My Account</h2>
								<ul>
									<li><a href="/userprofile" id="profile">My Account</a></li>
									<li><a href="#">Order History</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="or-footer-copyright-wrapper">
			<div class="container">
				<div class="or-footer-copyright-wrapper  d-flex justify-content-between align-items-center">
					<div class="or-footer-copyright-3">
						@ Copyright 2022. Door Step
					</div>
					{{-- <div class="footer-payment">
						<img src="assets/img/bg/f3-payment.png" alt="">
					</div> --}}
				</div>
			</div>
		</div>
	</section>
<!-- End of Footer  section
	============================================= -->


	<!-- For Js Library -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/appear.js"></script>
	<script src="assets/js/slick.js"></script>
	<script src="assets/js/jquery.counterup.min.js"></script>
	<script src="assets/js/waypoints.min.js"></script>
	<script src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="assets/js/wow.min.js"></script>
	<script src="assets/js/imagesloaded.pkgd.min.js"></script>
	<script src="assets/js/parallax-scroll.js"></script>
	<script src="assets/js/rbtools.min.js"></script>
	<script src="assets/js/rs6.min.js"></script>
	<script src="assets/js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery.session@1.0.0/jquery.session.min.js"></script>
    @yield('loginscript')
    @yield('registerscript')
    <script>
        $(document).ready(function() {
            console.log($.session.get('user'))
            if ($.session.get('user')) {
                $('#login').hide();
                $('#register').hide();

            } else {
                $('#profile').hide();
                $('#logout').hide();
                //$('#groceries').hide();
            }
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#country-dd').on('change', function () {
                var idCountry = this.value;
                $("#state-dd").html('');
                $.ajax({
                    url: "{{url('api/fetch-states')}}",
                    type: "POST",
                    data: {
                        country_id: idCountry,
                        _token: '{{csrf_token()}}'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#state-dd').html('<option value="">Select State</option>');
                        $.each(result.states, function (key, value) {
                            $("#state-dd").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                        $('#city-dd').html('<option value="">Select City</option>');
                    }
                });
            });
            $('#state-dd').on('change', function () {
                var idState = this.value;
                $("#city-dd").html('');
                $.ajax({
                    url: "{{url('api/fetch-cities')}}",
                    type: "POST",
                    data: {
                        state_id: idState,
                        _token: '{{csrf_token()}}'
                    },
                    dataType: 'json',
                    success: function (res) {
                        $('#city-dd').html('<option value="">Select City</option>');
                        $.each(res.cities, function (key, value) {
                            $("#city-dd").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>
