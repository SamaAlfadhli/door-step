<!-- Start of Banner section
	============================================= -->
	<section id="or-banner" class="or-banner-section" data-background="{{ asset('assets/img/bg/banner-bg1.jpg') }}">
		<div class="or-banner-content position-relative">
			<div class="container">
				<div class="or-banner-slider">
					<div class="or-banner-slider-item-wrapper headline-2 pera-content text-center">
						<div class="or-banner-slider-item">
							<h1>Always Fresh & <span>Organic</span>
							Vegetables</h1>
							<p>Our  Job is to filling  Your Tummy  with Delicious Healthy  Food
							and Fast free Delivery. </p>
							<div class="or-banner-btn d-flex justify-content-center">
								<a href="#">Shop Now</a>
								<a href="#">About us</a>
							</div>
						</div>
					</div>
					<div class="or-banner-slider-item-wrapper headline-2 pera-content text-center">
						<div class="or-banner-slider-item">
							<h1>Always Fresh & <span>Organic</span>
							Vegetables</h1>
							<p>Our  Job is to filling  Your Tummy  with Delicious Healthy  Food
							and Fast free Delivery. </p>
							<div class="or-banner-btn d-flex justify-content-center">
								<a href="#">Shop Now</a>
								<a href="#">About us</a>
							</div>
						</div>
					</div>
					<div class="or-banner-slider-item-wrapper headline-2 pera-content text-center">
						<div class="or-banner-slider-item">
							<h1>Always Fresh & <span>Organic</span>
							Vegetables</h1>
							<p>Our  Job is to filling  Your Tummy  with Delicious Healthy  Food
							and Fast free Delivery. </p>
							<div class="or-banner-btn d-flex justify-content-center">
								<a href="#">Shop Now</a>
								<a href="#">About us</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="banner-deco-img position-absolute">
				<img src="{{ asset('assets/img/bg/banner-side1.png') }}" alt="">
			</div>
		</div>
	</section>
<!-- End of Banner section
	============================================= -->
