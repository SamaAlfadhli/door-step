@extends('layouts.master')

@section('title', 'Door Step | Cart')

@section('breadcrumb')


	<section id="or-breadcrumbs" class="or-breadcrumbs-section position-relative" data-background="{{asset('assets/img/bg/bg-page-title.jpg') }}">
		<div class="background_overlay"></div>
		<div class="container">
			<div class="or-breadcrumbs-content text-center">
				<div class="page-title headline"><h1>Shop</h1></div>
				<div class="or-breadcrumbs-items ul-li">
					<ul>
						<li><a href="/">Home</a></li>
						<li><a href="/cart">Cart</a></li>
						<li>Checkout</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

@endsection


@section('inner-content')

{{-- Inner Page Content Comes here --}}
<section id="or-checkout" class="or-checkout-section">
    <div class="container">
        <div class="or-checkout-form-area">
            <div class="row">
                <div class="col-lg-6">
                    <div class="or-checkout-form headline pera-content">
                        <h2>Billing Details</h2>
                        <form action="#">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="or-bill-form">
                                        <label>First name *</label>
                                        <input type="text" placeholder="Jhon">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="or-bill-form">
                                        <label>Last name *</label>
                                        <input type="text" placeholder="Doe">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <label>Company Name</label>
                                        <input type="text" placeholder="Ex: x,y,z">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <select  id="country-dd" class="form-control" >
                                            <option value="">Select Country</option>
                                            @foreach ($countries as $data)
                                            <option value="{{$data->id}}">
                                                {{$data->name}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <select id="state-dd" class="form-control" >
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <select id="city-dd" class="form-control" >
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <input type="text" placeholder="House number and street name">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <input type="text" placeholder="Apartment,suite,unit,etc (optional)">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <label>Town / City *</label>
                                        <input type="text" placeholder="Ex: x,y,z">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <label>Country (optional)</label>
                                        <input type="text" placeholder="Ex: x,y,z">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <label>Postcode *</label>
                                        <input type="text" placeholder="Ex: x,y,z">
                                    </div>
                                </div>
                                <h2>Additional Information</h2>
                                <div class="col-md-12">
                                    <div class="or-bill-form">
                                        <textarea name="#" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="or-checkout-form headline pera-content">
                        <h2>Your Order</h2>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="product-name">Product</th>
                                    <th class="product-total-h">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="cart_item">
                                    <td class="product-name">
                                        Organic Cabbage - Orange, 0.5 Kg&nbsp;	
                                        <strong class="product-quantity">×&nbsp;1</strong>
                                    </td>
                                    <td class="product-total">
                                        <span class="Price-currencySymbol">$</span>4.00
                                    </td>
                                </tr>
                                <tr class="cart_item">
                                    <td class="product-name">
                                        Red Apple Envy&nbsp;
                                        <strong class="product-quantity">×&nbsp;1</strong>		
                                    </td>
                                    <td class="product-total">
                                        <span class="Price-currencySymbol">$</span>18.00
                                    </td>
                                </tr>
                                <tr class="cart_item">
                                    <td class="product-name">
                                        Green Bow&nbsp;				
                                        <strong class="product-quantity">×&nbsp;1</strong>	
                                    </td>
                                    <td class="product-total">
                                        <span class="Price-currencySymbol">$</span>4.00
                                    </td>
                                </tr>
                                <tr class="cart_item">
                                    <td class="product-name">
                                        Organic Lemon&nbsp;					
                                        <strong class="product-quantity">×&nbsp;1</strong>	
                                    </td>
                                    <td class="product-total">
                                        <span class="Price-currencySymbol">$</span>12.00
                                    </td>
                                </tr>
                                <tr class="cart_item">
                                    <td class="product-name">
                                        Diamond Almonds&nbsp;					
                                        <strong class="product-quantity">×&nbsp;1</strong>	
                                    </td>
                                    <td class="product-total">
                                        <span class="Price-currencySymbol">$</span>22.00
                                    </td>
                                </tr>
                                <tr class="cart_item">
                                    <td class="product-name">
                                        Herbal Tea&nbsp;					
                                        <strong class="product-quantity">×&nbsp;1</strong>
                                    </td>
                                    <td class="product-total">
                                        <span class="Price-currencySymbol">$</span>10.00
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="or-checkout-pay-item-wrapper">
                        <div class="or-checkout-pay-item">
                            <input type="radio" name="#" value="#">
                            <span>Direct bank transfer</span>
                        </div>
                        <div class="or-checkout-pay-item">
                            <input type="radio" name="#" value="#">
                            <span>Cash on delivery</span>
                        </div>
                        <div class="or-checkout-pay-item">
                            <input type="radio" name="#" value="#">
                            <span>Check payments</span>
                        </div>
                        <div class="or-checkout-pay-item">
                            <input type="radio" name="#" value="#">
                            <span>PayPal</span>
                        </div>
                        <p>Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our <a href="#">privacy policy.</a></p>
                        <div class="or-btn-2">
                            <a class="d-flex justify-content-center align-items-center" href="#">Place Order</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection


