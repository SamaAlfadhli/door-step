@extends('layouts.master')

@section('title', 'Door Step | Cart')

@section('breadcrumb')


	<section id="or-breadcrumbs" class="or-breadcrumbs-section position-relative" data-background="{{asset('assets/img/bg/bg-page-title.jpg') }}">
		<div class="background_overlay"></div>
		<div class="container">
			<div class="or-breadcrumbs-content text-center">
				<div class="page-title headline"><h1>UserName</h1></div>
				<div class="or-breadcrumbs-items ul-li">
					<ul>
						<li><a href="/">Home</a></li>
						<li>My Profile</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

@endsection


@section('inner-content')

{{-- Inner Page Content Comes here --}}
<section id="or-team-details" class="or-team-details-section">
    <div class="container">
        <div class="ord-team-details-content">
            <div class="row">
                <div class="col-lg-3">
                    <div class="ord-team-details-sidebar">
                        <div class="ord-team-details-sidebar-item">
                            <div class="ord-team-member-inner-item">
                                <div class="ord-team-member-img text-center position-relative">
                                    <img src="{{ asset('assets/img/team/tmd.jpg') }}" alt="">
                                </div>
                                <div class="ord-team-member-text headline text-center pera-content">
                                    <h3>Stephen Louis</h3>
                                    <span>Seller </span>
                                </div>
                                <div class="ord-team-member-contact ul-li-block">
                                    <ul>
                                        <li><i class="far fa-phone-alt"></i>+91 7581 458 21</li>
                                        <li><i class="fal fa-envelope"></i>Support @gmail.com</li>
                                        <li><i class="far fa-map-marker-alt"></i>13 Street Road, NY, USA</li>
                                    </ul>
                                </div>
                                <div class="ord-team-member-social">
                                    <div class="or-btn-2">
                                        <a class="d-flex justify-content-center align-items-center" href="/my-orders">View Orders</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="ord-team-details-text-wrap headline pera-content">
                        <div class="ord-team-details-text-item">
                            <h3>Edit Profile</h3>
                            
                        </div>
                        <div class="ord-team-details-text-item ul-li-block">
                            <div class="or-checkout-form headline pera-content">
                                <form>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="or-bill-form">
                                                <label>First name *</label>
                                                <input type="text" placeholder="Ex: x,y,z" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="or-bill-form">
                                                <label>Last name *</label>
                                                <input type="text" placeholder="Ex: x,y,z" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="or-bill-form">
                                                <label>Phone Number *</label>
                                                <input type="tel" placeholder="5338828288" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="or-bill-form">
                                                <label>Email *</label>
                                                <input name="email" type="email" placeholder="example@example.com" class="form-control" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="or-bill-form">
                                                <label>Password *</label>
                                                <input name="email" type="password" class="form-control" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Address *</label>
                                            <div class="or-bill-form">
                                                <select  id="country-dd" class="form-control" >
                                                    <option value="">Select Country</option>
                                                    @foreach ($countries as $data)
                                                    <option value="{{$data->id}}">
                                                        {{$data->name}}
                                                    </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="or-bill-form">
                                                <select id="state-dd" class="form-control" >
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="or-bill-form">
                                                <select id="city-dd" class="form-control" >
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="or-bill-form">
                                                <input type="text" placeholder="House number and street name" >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="or-bill-form">
                                                <input type="text" placeholder="Apartment,suite,unit,etc (optional)" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="login-button text-center ">
                                        <button type="submit" value="Update Profile" class="btn btn-sm btn-success">Update Profile</button>
                                    </div>
                                </form>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection


