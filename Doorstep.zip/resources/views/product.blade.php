@extends('layouts.master')

@section('title', 'Door Step | Product')

@section('breadcrumb')


	<section id="or-breadcrumbs" class="or-breadcrumbs-section position-relative" data-background="{{asset('assets/img/bg/bg-page-title.jpg') }}">
		<div class="background_overlay"></div>
		<div class="container">
			<div class="or-breadcrumbs-content text-center">
				<div class="page-title headline"><h1>Shop</h1></div>
				<div class="or-breadcrumbs-items ul-li">
					<ul>
						<li><a href="/">Home</a></li>
						<li><a href="/shop-page">Shop</a></li>
						<li>Product Name</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

@endsection


@section('inner-content')

{{-- Inner Page Content Comes here --}}
<section id="or-shop-details" class="or-shop-details-section">
    <div class="container">
        <div class="or-shop-details-content">
            <div class="row">
                <div class="col-lg-6">
                    <div class="shop-details-img-slider-area">
                        <div class="shop-details-img-slider">
                            <div class="shop-details-img-wrap">
                                <img src="{{ asset('assets/img/product/h6-product3.png') }}" alt="" data-zoomed="{{ asset('assets/img/product/h6-product3.png') }}">
                            </div>
                            <div class="shop-details-img-wrap">
                                <img src="{{ asset('assets/img/product/h6-product4.png') }}" alt="" data-zoomed="{{ asset('assets/img/product/h6-product4.png') }}">
                            </div>
                            <div class="shop-details-img-wrap">
                                <img src="{{ asset('assets/img/product/h6-product1.png') }}" alt="" data-zoomed="{{ asset('assets/img/product/h6-product1.png') }}">
                            </div>
                        </div>
                        <div class="shop-details-img-thumb">
                            <div class="or-thumb-img">
                                <img src="{{ asset('assets/img/product/h6-product3.png') }}" alt="">
                            </div>
                            <div class="or-thumb-img">
                                <img src="{{ asset('assets/img/product/h6-product4.png') }}" alt="">
                            </div>
                            <div class="or-thumb-img">
                                <img src="{{ asset('assets/img/product/h6-product1.png') }}" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="shop-details-text  headline pera-content">
                        <div class="shop-details-title">
                            <h3>Milk Shake</h3>
                        </div>
                        <div class="shop-details-rate-review ul-li d-flex">
                            <div class="shop-details-rate">
                                <ul>
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                </ul>
                            </div>
                            <div class="shop-details-review">(4.9 Based on 02 Reviews)</div>
                            <div class="shop-details-review"><span>02 Reviews</span> <span>24 orders</span></div>
                        </div>
                        <div class="shop-details-price">US $3.525-$7.15</div>
                        <div class="shop-details-text-decs">
                            Sumptuous, filling, and temptingly healthy, our Biona Organic Granola with Wild Berries is just the thing to get you out of bed. The goodness of rolled wholegrain oats are combined with a variety of tangy organic berries, and baked into crispy clusters that are as nutritious.
                        </div>
                        <div class="shop-details-option color-option ul-li">
                            <span class="option-title">Color:</span>
                            <ul>
                                <li class="color-1 active"></li>
                                <li class="color-2"></li>
                                <li class="color-3"></li>
                                <li class="color-4"></li>
                            </ul>
                        </div>
                        <div class="shop-details-option">
                            <span class="option-title">Quantity:</span>
                            <div class="shop-quantity-option d-flex">
                                <div class="quantity-field position-relative  d-inline-block">
                                    <input type="text" name="select1" value="1" class="quantity-input-arrow quantity-input-2  text-center">
                                </div>
                                <div class="stock-avaiable">85 pieces available </div>
                            </div>
                        </div>
                        <div class="shop-details-btn ">
                            <a href="/cart">Add To Cart</a>
                        </div>
                        <div class="shop-details-product-code ul-li-block">
                            <ul>	
                                <li><span>SKU: </span> WT-05789-567-78</li>
                                <li><span>Category: </span>Beverage</li>
                            </ul>	
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="or-shop-details-tab" class="or-shop-details-tab-section">
    <div class="container">
        <div class="or-shop-details-review-tab-content">
            <div class="or-shop-review-tab-btn">
                <ul class="nav nav-tabs justify-content-center" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Description</button>
                    </li>
                </ul>
            </div>
            <div class="or-shop-details-tab-textarea">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <div class="shop-details-description-text  text-center">
                            There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true gener
                            ator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection


