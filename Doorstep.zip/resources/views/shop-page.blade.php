@extends('layouts.master')

@section('title', 'Door Step | Groceries')

@section('breadcrumb')


	<section id="or-breadcrumbs" class="or-breadcrumbs-section position-relative" data-background="{{asset('assets/img/bg/bg-page-title.jpg') }}">
		<div class="background_overlay"></div>
		<div class="container">
			<div class="or-breadcrumbs-content text-center">
				<div class="page-title headline"><h1>Shop</h1></div>
				<div class="or-breadcrumbs-items ul-li">
					<ul>
						<li><a href="/">Home</a></li>
						<li>Shop</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

@endsection


@section('inner-content')

{{-- Inner Page Content Comes here --}}
<section id="or-shop-product" class="or-shop-product-section">
    <div class="container">
        <div class="or-section-title headline pera-content text-center middle-align">
            <span class="sub-title">Products</span>
            <h2>All of our products are
            organic & fresh.</h2>
        </div>
        <div class="or-product-shop-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="or-product-innerbox-item type-1 text-center position-relative">
                            <div class="e-commerce-btn">
                                <a href="/cart"><i class="fal fa-shopping-cart"></i></a>
                                <a href="/product"><i class="fal fa-eye"></i></a>
                            </div>
                            <div class="or-product-inner-img">
                                <img src="{{ asset('assets/img/product/pro1.jpg') }}" alt="">
                            </div>
                            <div class="or-product-inner-text headline">
                                <h3><a href="/product" tabindex="0">Organic Juice</a></h3>
                                <span class="price">$10.00-$20.00</span>
                                <div class="or-product-rate ul-li">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="or-product-btn text-center">
                                <a class="d-flex justify-content-center align-items-center" href="/cart" tabindex="0">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="or-product-innerbox-item type-1 text-center position-relative">
                            <div class="e-commerce-btn">
                                <a href="/cart"><i class="fal fa-shopping-cart"></i></a>
                                <a href="/product"><i class="fal fa-eye"></i></a>
                            </div>
                            <div class="or-product-inner-img">
                                <img src="{{ asset('assets/img/product/pro2.jpg') }}" alt="">
                            </div>
                            <div class="or-product-inner-text headline">
                                <h3><a href="/product">Fresh Orange</a></h3>
                                <span class="price">$10.00-$20.00</span>
                                <div class="or-product-rate ul-li">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="or-product-btn text-center">
                                <a class="d-flex justify-content-center align-items-center" href="/cart">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="or-product-innerbox-item type-1 text-center position-relative">
                            <div class="e-commerce-btn">
                                <a href="/cart"><i class="fal fa-shopping-cart"></i></a>
                                <a href="/product"><i class="fal fa-eye"></i></a>
                            </div>
                            <div class="or-product-inner-img">
                                <img src="{{asset('assets/img/product/pro3.jpg') }}" alt="">
                            </div>
                            <div class="or-product-inner-text headline">
                                <h3><a href="/product">Organic Cabbage</a></h3>
                                <span class="price">$10.00-$20.00</span>
                                <div class="or-product-rate ul-li">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="or-product-btn text-center">
                                <a class="d-flex justify-content-center align-items-center" href="/cart">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="or-product-innerbox-item type-1 text-center position-relative">
                            <div class="e-commerce-btn">
                                <a href="/cart"><i class="fal fa-shopping-cart"></i></a>
                                <a href="/product"><i class="fal fa-eye"></i></a>
                            </div>
                            <div class="or-product-inner-img">
                                <img src="{{ asset('assets/img/product/pro4.jpg') }}" alt="">
                            </div>
                            <div class="or-product-inner-text headline">
                                <h3><a href="/product">Brown Bread</a></h3>
                                <span class="price">$10.00-$20.00</span>
                                <div class="or-product-rate ul-li">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="or-product-btn text-center">
                                <a class="d-flex justify-content-center align-items-center" href="/cart">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="or-product-innerbox-item type-1 text-center position-relative">
                            <div class="e-commerce-btn">
                                <a href="/cart"><i class="fal fa-shopping-cart"></i></a>
                                <a href="/product"><i class="fal fa-eye"></i></a>
                            </div>
                            <div class="or-product-inner-img">
                                <img src="{{ asset('assets/img/product/pro5.jpg') }}" alt="">
                            </div>
                            <div class="or-product-inner-text headline">
                                <h3><a href="/product" tabindex="0">Fresh Juice</a></h3>
                                <span class="price">$10.00-$20.00</span>
                                <div class="or-product-rate ul-li">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="or-product-btn text-center">
                                <a class="d-flex justify-content-center align-items-center" href="#" tabindex="0">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="or-product-innerbox-item type-1 text-center position-relative">
                            <div class="e-commerce-btn">
                                <a href="/cart"><i class="fal fa-shopping-cart"></i></a>
                                <a href="/product"><i class="fal fa-eye"></i></a>
                            </div>
                            <div class="or-product-inner-img">
                                <img src="{{ asset('assets/img/product/pro6.jpg') }}" alt="">
                            </div>
                            <div class="or-product-inner-text headline">
                                <h3><a href="/product">Organic Rice</a></h3>
                                <span class="price">$10.00-$20.00</span>
                                <div class="or-product-rate ul-li">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="or-product-btn text-center">
                                <a class="d-flex justify-content-center align-items-center" href="/cart">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="or-product-innerbox-item type-1 text-center position-relative">
                            <div class="e-commerce-btn">
                                <a href="/cart"><i class="fal fa-shopping-cart"></i></a>
                                <a href="/product"><i class="fal fa-eye"></i></a>
                            </div>
                            <div class="or-product-inner-img">
                                <img src="{{ asset('assets/img/product/pro7.png') }}" alt="">
                            </div>
                            <div class="or-product-inner-text headline">
                                <h3><a href="/product">Red Apple Envy</a></h3>
                                <span class="price">$10.00-$20.00</span>
                                <div class="or-product-rate ul-li">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="or-product-btn text-center">
                                <a class="d-flex justify-content-center align-items-center" href="/cart">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="or-product-innerbox-item type-1 text-center position-relative">
                            <div class="e-commerce-btn">
                                <a href="/cart"><i class="fal fa-shopping-cart"></i></a>
                                <a href="/product"><i class="fal fa-eye"></i></a>
                            </div>
                            <div class="or-product-inner-img">
                                <img src="{{ asset('assets/img/product/pro8.jpg') }}" alt="">
                            </div>
                            <div class="or-product-inner-text headline">
                                <h3><a href="/product">Oat Cake</a></h3>
                                <span class="price">$10.00-$20.00</span>
                                <div class="or-product-rate ul-li">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="or-product-btn text-center">
                                <a class="d-flex justify-content-center align-items-center" href="/cart">Add To Cart</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="or-pagination text-center ul-li">
                    <ul>
                        <li><a class="active" href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection


