<?php $__env->startSection('title', 'Door Step | Register'); ?>

<?php $__env->startSection('inner-content'); ?>


<section id="or-login" class="or-login-section" style="background: #76a713; margin-top:50px;">
    <div class="or-login-content sign-login-area d-flex align-items-center justify-content-center">
        <div class="or-checkout-form headline pera-content">
            <form>
                <div class="row">
                    <div class="col-md-6">
                        <div class="or-bill-form">
                            <label>First name *</label>
                            <input type="text" placeholder="Ex: x,y,z" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="or-bill-form">
                            <label>Last name *</label>
                            <input type="text" placeholder="Ex: x,y,z" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="or-bill-form">
                            <label>Phone Number *</label>
                            <input type="tel" placeholder="5338828288" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="or-bill-form">
                            <label>Email *</label>
                            <input name="email" type="email" placeholder="example@example.com" class="form-control" required="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="or-bill-form">
                            <label>Password *</label>
                            <input name="email" type="password" class="form-control" required="">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <label>Address *</label>
                        <div class="or-bill-form">
                            <select  id="country-dd" class="form-control" >
                                <option value="">Select Country</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>">
                                    <?php echo e($data->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="or-bill-form">
                            <select id="state-dd" class="form-control" >
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="or-bill-form">
                            <select id="city-dd" class="form-control" >
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="or-bill-form">
                            <input type="text" placeholder="House number and street name" >
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="or-bill-form">
                            <input type="text" placeholder="Apartment,suite,unit,etc (optional)" >
                        </div>
                    </div>
                </div>
                <div class="login-button text-center">
                    <button type="submit" value="Register">Register</button>
                </div>
                <div class="col-md-12 text-white text-center">
                    <p><b>OR</b></p>
                    <p><a href="/login" class="">Login</a></p>
                </div>
            </form>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('registerscript'); ?>

<script>
    $("form").submit(async (event) => {
    const email = event.target.email.value;
    const password = event.target.password.value;
    event.preventDefault();
    try {
        event.preventDefault();


        // $.ajax({
        //     mode: 'no-cors',
        //     url: '/api/register',
        //     headers: {
        //         'Content-Type': 'application/json'
        //     },
        //     crossDomain: true,
        //     type: "POST",
        //     /* or type:"GET" or type:"PUT" */
        //     dataType: "json",
        //     data: jQuery.param({ email: email, password : password}),
        //     success: function(result) {
        //         console.log(result);
        //     },
        //     error: function(xr, err, stats) {
        //         console.log(xr);
        //     }
        // });

        window.location.assign("/login");
    } catch (ex) {
        alert("Error occured..." + ex)
    }



    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PP Projects\Selis\Doorstep\resources\views/register.blade.php ENDPATH**/ ?>