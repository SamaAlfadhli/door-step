<!-- Start of header section
	============================================= -->
	<header id="organio-header" class="organio-header-section header-style-three">
		<div class="or-header-top">
			<div class="container">
				<div class="or-header-top-content d-flex justify-content-between align-items-center">
					<div class="or-header-top-slug">
						Groceries at your Door Step
					</div>
					<div class="or-header-top-social">
						<a href="#"><i class="fab fa-facebook-f"></i></a>
						<a href="#"><i class="fab fa-twitter"></i></a>
						<a href="#"><i class="fab fa-dribbble"></i></a>
						<a href="#"><i class="fab fa-behance"></i></a>
					</div>
					<div class="or-header-top-login-btn position-relative">
						<a id="login" href="/login">Login</a>
						<a id="register" href="/register">Register</a>
						<a id="logout" href="/login">Log Out</a>
					</div>
				</div>
			</div>
		</div>
		<div class="or-header-main-menu">
			<div class="container">
				<div class="or-header-main-menu-content d-flex justify-content-between align-items-center">
					<div class="site-logo">
						<a href="/"><img src="<?php echo e(asset('assets/img/logo/logo3.png')); ?>" alt=""></a>
					</div>
					<div class="or-header-main-navigation-btn d-flex">
						<nav class="main-navigation-area clearfix ul-li">
							<ul class="menu-navigation">
								<li><a href="/">Home</a></li>
                                <li class="dropdown" id="groceries">
									<a href="/shop-page">Groceries</a>
									<ul class="dropdown-menu clearfix">
										<li><a href="/shop-page">Cleaning Products </a></li>
										<li><a href="/shop-page">Snacks</a></li>
										<li><a href="/shop-page">Fruits</a></li>
									</ul>
								</li>
                                <li class="dropdown" id="profile">
									<a href="/userprofile">Profile</a>
									<ul class="dropdown-menu clearfix">
										<li><a href="/my-orders">My Orders </a></li>
										<li><a href="/track-order">Track Orders</a></li>
									</ul>
								</li>
							</ul>
						</nav>
						<div class="or-header-right-btn">
							<button class="or-canvas-cart-trigger"><i class="fal fa-shopping-cart"></i></button>
							<button class="search-box-outer"><i class="fas fa-search"></i></button>
						</div>
					</div>
				</div>
				<div class="mobile_menu position-relative">
					<div class="mobile_menu_button open_mobile_menu">
						<i class="fal fa-bars"></i>
					</div>
					<div class="mobile_menu_wrap">
						<div class="mobile_menu_overlay open_mobile_menu"></div>
						<div class="mobile_menu_content">
							<div class="mobile_menu_close open_mobile_menu">
								<i class="fal fa-times"></i>
							</div>
							<div class="m-brand-logo">
								
								<a href="/"><img src="<?php echo e(asset('assets/img/logo/logo1.png')); ?>" alt=""></a>
							</div>
							<div class="mobile-search-wrapper position-relative">
								<form action="#">
									<input type="text" placeholder="Search Here...">
									<button><i class="fas fa-search"></i></button>
								</form>
							</div>
							<nav class="mobile-main-navigation  clearfix ul-li">
								<ul id="m-main-nav" class="navbar-nav text-capitalize clearfix">
									<li><a href="/">Home</a></li>
									<li><a href="/shop-page">Groceries</a></li>
									<li class="dropdown">
										<a href="/userprofile">Profile</a>
										<ul class="dropdown-menu clearfix">
											<li><a href="/my-orders">My Orders </a></li>
											<li><a href="/track-order">Track Orders</a></li>
										</ul>
									</li>
								</ul>
							</nav>
						</div>
					</div>
					<!-- /Mobile-Menu -->
				</div>
			</div>
		</div>
	</header>
	<div class="search-popup">
		<button class="close-search style-two"><span class="fal fa-times"></span></button>
		<button class="close-search"><span class="fa fa-arrow-up"></span></button>
		<form method="post" action="#">
			<div class="form-group">
				<input type="search" name="search-field" value="" placeholder="Search Here" required="">
				<button type="submit"><i class="fa fa-search"></i></button>
			</div>
		</form>
	</div>
	<div class="or-ofcanvas-cart-wrapper">
		<div class="or-ofcanvas-cart-content">
			<div class="title-area d-flex justify-content-between align-items-center">
				<div class="cart-title">
					<span>Cart</span>
				</div>
				<div class="cart-close">
					<button class="or-canvas-cart-trigger"><i class="fal fa-times"></i></button>
				</div>
			</div>
			<div class="or-ofcart-product-wrapper">
				<div class="or-ofcart-product-item d-flex align-items-center position-relative">
					<div class="pro-remove position-absolute"><i class="fal fa-times"></i></div>
					<div class="or-ofcart-product-img">
						<img src="assets/img/product/pro1.jpg" alt="">
					</div>
					<div class="or-ofcart-product-text headline">
						<h3><a href="#">Organic Juice</a></h3>
						<span>1 x $4.00</span>
					</div>
				</div>
				<div class="or-ofcart-product-item d-flex align-items-center position-relative">
					<div class="pro-remove position-absolute"><i class="fal fa-times"></i></div>
					<div class="or-ofcart-product-img">
						<img src="assets/img/product/pro2.jpg" alt="">
					</div>
					<div class="or-ofcart-product-text headline">
						<h3><a href="#">Fresh Orange</a></h3>
						<span>1 x $4.00</span>
					</div>
				</div>
				<div class="or-ofcart-product-item d-flex align-items-center position-relative">
					<div class="pro-remove position-absolute"><i class="fal fa-times"></i></div>
					<div class="or-ofcart-product-img">
						<img src="assets/img/product/pro3.jpg" alt="">
					</div>
					<div class="or-ofcart-product-text headline">
						<h3><a href="#">Organic Onion</a></h3>
						<span>1 x $4.00</span>
					</div>
				</div>
			</div>
			<div class="or-ofcart-total text-center">
				<span>Subtotal: $4.00</span>
				<div class="total-btn">
					<a href="/cart">View Cart</a>
					<a href="/checkout">Checkout</a>
				</div>
			</div>
		</div>
	</div>
<!-- End of header section
	============================================= -->
<?php /**PATH D:\PP Projects\Selis\Doorstep\resources\views/layouts/inc/header.blade.php ENDPATH**/ ?>