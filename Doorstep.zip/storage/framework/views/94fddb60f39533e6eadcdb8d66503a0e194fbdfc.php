

<?php $__env->startSection('title', 'Door Step | Track Order'); ?>

<?php $__env->startSection('breadcrumb'); ?>


	<section id="or-breadcrumbs" class="or-breadcrumbs-section position-relative" data-background="<?php echo e(asset('assets/img/bg/bg-page-title.jpg')); ?>">
		<div class="background_overlay"></div>
		<div class="container">
			<div class="or-breadcrumbs-content text-center">
				<div class="page-title headline"><h1>User Name</h1></div>
				<div class="or-breadcrumbs-items ul-li">
					<ul>
						<li><a href="/">Home</a></li>
						<li><a href="/userprofile">Profile</a></li>
						<li><a href="/my-orders">My Orders</a></li>
						<li>Order #</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('inner-content'); ?>


<section id="or-main-cart" class="or-main-cart-section">
    <div class="container">
        <div class="or-main-cart-content">
            <div class="row">
                <div class="col-lg-8">
                    <div class="or-cart-content-table table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="product-remove">&nbsp;</th>
                                    <th class="product-thumbnail">&nbsp;</th>
                                    <th class="product-name">Product</th>
                                    <th class="product-quantity">Quantity</th>
                                    <th class="product-subtotal">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="product-remove"> <a href="#" class="remove">×</a></td>

                                    <td class="product-thumbnail"> <a href="#"><img src="<?php echo e(asset('assets/img/product/pro1.jpg')); ?>" class="cart-thumb-img" alt=""></a></td>
                                    <td class="product-name" data-title="Product"> <a href="/product">Organic Cabbage - Orange, 0.5 Kg</a></td>
                                    
                                    <td>
                                        <div class="quantity-field position-relative  d-inline-block">
                                           5
                                        </div>
                                    </td>
                                    <td class="product-subtotal"> <span><bdi><span class="Price-currencySymbol">$</span>4.00</bdi></span></td>
                                </tr>
                                <tr>
                                    <td class="product-remove"> <a href="#" class="remove">×</a></td>

                                    <td class="product-thumbnail"> <a href="#"><img src="<?php echo e(asset('assets/img/product/pro2.jpg')); ?>" class="cart-thumb-img" alt=""></a></td>
                                    <td class="product-name" data-title="Product"> <a href="/product">Fresh - Orange, 0.5 Kg</a></td>
                                    
                                    <td>
                                        <div class="quantity-field position-relative  d-inline-block">
                                           5
                                        </div>
                                    </td>
                                    <td class="product-subtotal"> <span><bdi><span class="Price-currencySymbol">$</span>89.00</bdi></span></td>
                                </tr>
                                <tr>
                                    <td class="product-remove"> <a href="#" class="remove">×</a></td>

                                    <td class="product-thumbnail"> <a href="#"><img src="<?php echo e(asset('assets/img/product/pro3.jpg')); ?>" class="cart-thumb-img" alt=""></a></td>
                                    <td class="product-name" data-title="Product"> <a href="/product">Organic Cabbage - Onion, 2.0 Kg</a></td>
                                    
                                    <td>
                                        <div class="quantity-field position-relative  d-inline-block">
                                           5
                                        </div>
                                    </td>
                                    <td class="product-subtotal"> <span><bdi><span class="Price-currencySymbol">$</span>24.00</bdi></span></td>
                                </tr>
                                <tr>
                                    <td class="product-remove"> <a href="#" class="remove">×</a></td>

                                    <td class="product-thumbnail"> <a href="#"><img src="<?php echo e(asset('assets/img/product/pro4.jpg')); ?>" class="cart-thumb-img" alt=""></a></td>
                                    <td class="product-name" data-title="Product"> <a href="/product">Healthy Bread, 2.3 Kg</a></td>
                                    
                                    <td>
                                        <div class="quantity-field position-relative  d-inline-block">
                                           5
                                        </div>
                                    </td>
                                    <td class="product-subtotal"> <span><bdi><span class="Price-currencySymbol">$</span>13.00</bdi></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="or-cart-total-warpper text-center headline pera-content top-sticky">
                        <h3>Order Status</h3>
                        <table>
                            <tbody>
                                <tr>
                                    <td>
                                        <p class="v-title">Order Date/Time</p>
                                    </td>
                                    <td>
                                        <p class="v-price">	5th, January 2022 at 11:30PM</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <p class="v-title">Delivery Status</p>
                                    </td>
                                    <td>
                                        <p class="v-price">	Delivered</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <a class="d-flex justify-content-center align-items-center" href="/my-orders"><i class="fa fa-chevron-left"></i> Back to Orders</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PP Projects\Selis\Doorstep\resources\views/track-order.blade.php ENDPATH**/ ?>