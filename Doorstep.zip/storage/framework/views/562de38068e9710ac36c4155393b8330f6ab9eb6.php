<?php $__env->startSection('title', 'Door Step'); ?>

<?php $__env->startSection('banner'); ?>


	<section id="or-banner" class="or-banner-section" data-background="<?php echo e(asset('assets/img/bg/banner-bg1.jpg')); ?>">
		<div class="or-banner-content position-relative">
			<div class="container">
				<div class="or-banner-slider">
					<div class="or-banner-slider-item-wrapper headline-2 pera-content text-center">
						<div class="or-banner-slider-item">
							<h1>Always Fresh & <span>Organic</span>
							Vegetables</h1>
							<p>Our  Job is to filling  Your Tummy  with Delicious Healthy  Food
							and Fast free Delivery. </p>
						</div>
					</div>
					<div class="or-banner-slider-item-wrapper headline-2 pera-content text-center">
						<div class="or-banner-slider-item">
							<h1>Always Fresh & <span>Organic</span>
							Vegetables</h1>
							<p>Our  Job is to filling  Your Tummy  with Delicious Healthy  Food
							and Fast free Delivery. </p>
						</div>
					</div>
					<div class="or-banner-slider-item-wrapper headline-2 pera-content text-center">
						<div class="or-banner-slider-item">
							<h1>Always Fresh & <span>Organic</span>
							Vegetables</h1>
							<p>Our  Job is to filling  Your Tummy  with Delicious Healthy  Food
							and Fast free Delivery. </p>
						</div>
					</div>
				</div>
			</div>
			<div class="banner-deco-img position-absolute">
				<img src="<?php echo e(asset('assets/img/bg/banner-side1.png')); ?>" alt="">
			</div>
		</div>
	</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('inner-content'); ?>;


	<section id="or-feature" class="or-feature-section">
		<div class="container">
			<div class="or-section-title-3 text-center pera-content headline-2">
				<h2>Our Special <span>Features</span></h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
			</div>
			<div class="or-feature-content position-relative">
				<span class="section-deco1 position-absolute"><img src="<?php echo e(asset('assets/img/deco1.png')); ?>" alt=""></span>
				<span class="section-deco2 position-absolute"><img src="<?php echo e(asset('assets/img/deco2.png')); ?>" alt=""></span>
				<span class="section-deco3 position-absolute"><img src="<?php echo e(asset('assets/img/deco3.png')); ?>" alt=""></span>
				<div class="row justify-content-center">
					<div class="col-lg-4 col-md-6">
						<div class="or-feature-innerbox text-center headline-2 pera-content">
							<div class="or-feature-img">
								<img src="<?php echo e(asset('assets/img/icon/ft-icon1.png')); ?>" alt="">
							</div>
							<div class="or-feature-text">
								<h3>Fresh Organic Vegetable</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do dunt ut labore.</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="or-feature-innerbox text-center headline-2 pera-content">
							<div class="or-feature-img">
								<img src="<?php echo e(asset('assets/img/icon/ft-icon2.png')); ?>" alt="">
							</div>
							<div class="or-feature-text">
								<h3>Fast & Easy Grocery Delivery</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do dunt ut labore.</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="or-feature-innerbox text-center headline-2 pera-content">
							<div class="or-feature-img">
								<img src="<?php echo e(asset('assets/img/icon/ft-icon3.png')); ?>" alt="">
							</div>
							<div class="or-feature-text">
								<h3>Very Easy Payment System</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do dunt ut labore.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="or-popular-category" class="or-popular-category-section">
		<div class="container">
			<div class="or-popular-category-top-content d-flex justify-content-between align-items-end">
				<div class="or-section-title-3 pera-content headline-2">
					<h2>Popular <span>Category</span></h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
				</div>
				<div class="carousel_nav  clearfix">
					<button type="button" class="or-pop-cat-left_arrow"><i class="far fa-chevron-left"></i></button>
					<button type="button" class="or-pop-cat-right_arrow"><i class="far fa-chevron-right"></i></button>
				</div>
			</div>
			<div class="or-popular-category-slider-area">
				<div class="or-popular-category-slider-wrap">
					<div class="or-popular-cat-slider">
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon1.png')); ?>" alt="">
									</div>
									<h3> Vegetable</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon2.png')); ?>" alt="">
									</div>
									<h3>  Fruits</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon3.png')); ?>" alt="">
									</div>
									<h3>  Dried</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon4.png')); ?>" alt="">
									</div>
									<h3>  Juice</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon5.png')); ?>" alt="">
									</div>
									<h3>  Salad</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon6.png')); ?>" alt="">
									</div>
									<h3>  Organic</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon1.png')); ?>" alt="">
									</div>
									<h3> Vegetable</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon2.png')); ?>" alt="">
									</div>
									<h3>  Fruits</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon3.png')); ?>" alt="">
									</div>
									<h3>  Dried</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon4.png')); ?>" alt="">
									</div>
									<h3>  Juice</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon5.png')); ?>" alt="">
									</div>
									<h3>  Salad</h3>
								</a>
							</div>
						</div>
						<div class="organio-inner-item">
							<div class="or-p-cat-innerbox headline-2">
								<a href="/shop-page">
									<div class="or-p-cat-img">
										<img src="<?php echo e(asset('assets/img/category/h5-icon6.png')); ?>" alt="">
									</div>
									<h3>  Organic</h3>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>




	<section id="or-trending-product" class="or-trending-product-section">
		<div class="container">
			<div class="or-trending-product-top d-flex justify-content-between align-items-end">
				<div class="or-section-title-3 pera-content headline-2">
					<h2>Trending <span>Products</span></h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
				</div>
				<div class="or-trending-item-filter-btn ul-li">
					<ul id="filters" class="nav-gallery">
						<li class="filtr-button filtr-active" data-filter="all">All Product</li>
						<li class="filtr-button" data-filter="1">Fresh Fruits</li>
						<li class="filtr-button" data-filter="2">Nature</li>
						<li class="filtr-button" data-filter="3">Recpies </li>
						<li class="filtr-button" data-filter="4">Vegetable </li>
					</ul>
				</div>
			</div>
			<div class="or-trending-item-wrapper filtr-container row">
				<div class="col-lg-3 col-sm-6 filtr-item" data-category="1, 3, 4" data-sort="Busy streets">
					<div class="or-trending-product-item text-center">
						<div class="or-trend-item-img position-relative">
							<img src="<?php echo e(asset('assets/img/product/tp2.png')); ?>" alt="">
							<div class="e-commerce-btn">
								<a href="/cart"><i class="fal fa-shopping-cart"></i></a>
								<a href="/product"><i class="fal fa-eye"></i></a>
							</div>
						</div>
						<div class="or-trend-item-text headline-2">
							<h3><a href="/product">Fresh Orange</a></h3>
							<span>$12.00 – $65.00 </span>
							<a class="add-cart-btn" href="/cart">Add To Cart</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 filtr-item" data-category="2, 3, 4" data-sort="Busy streets">
					<div class="or-trending-product-item text-center">
						<div class="or-trend-item-img position-relative">
							<img src="<?php echo e(asset('assets/img/product/tp1.png')); ?>" alt="">
							<div class="e-commerce-btn">
								<a href="/cart"><i class="fal fa-shopping-cart"></i></a>
								<a href="/product"><i class="fal fa-eye"></i></a>
							</div>
						</div>
						<div class="or-trend-item-text headline-2">
							<h3><a href="/product">Red Apple Envy</a></h3>
							<span>$12.00 – $65.00 </span>
							<a class="add-cart-btn" href="/cart">Add To Cart</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 filtr-item" data-category="1, 2, 4" data-sort="Busy streets">
					<div class="or-trending-product-item text-center">
						<div class="or-trend-item-img position-relative">
							<img src="<?php echo e(asset('assets/img/product/tp3.png')); ?>" alt="">
							<div class="e-commerce-btn">
								<a href="/cart"><i class="fal fa-shopping-cart"></i></a>
								<a href="/product"><i class="fal fa-eye"></i></a>
							</div>
						</div>
						<div class="or-trend-item-text headline-2">
							<h3><a href="/product">Green Bow</a></h3>
							<span>$12.00 – $65.00 </span>
							<a class="add-cart-btn" href="/cart">Add To Cart</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 filtr-item" data-category="2, 1, 3" data-sort="Busy streets">
					<div class="or-trending-product-item text-center">
						<div class="or-trend-item-img position-relative">
							<img src="<?php echo e(asset('assets/img/product/tp4.png')); ?>" alt="">
							<div class="e-commerce-btn">
								<a href="/cart"><i class="fal fa-shopping-cart"></i></a>
								<a href="/product"><i class="fal fa-eye"></i></a>
							</div>
						</div>
						<div class="or-trend-item-text headline-2">
							<h3><a href="/product">Organic Lemon</a></h3>
							<span>$12.00 <del>$15.00</del> </span>
							<a class="add-cart-btn" href="/cart">Add To Cart</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 filtr-item" data-category="2, 3, 4" data-sort="Busy streets">
					<div class="or-trending-product-item text-center">
						<div class="or-trend-item-img position-relative">
							<img src="<?php echo e(asset('assets/img/product/tp5.png')); ?>" alt="">
							<div class="e-commerce-btn">
								<a href="/cart"><i class="fal fa-shopping-cart"></i></a>
								<a href="/product"><i class="fal fa-eye"></i></a>
							</div>
						</div>
						<div class="or-trend-item-text headline-2">
							<h3><a href="/product">Organic Carrot</a></h3>
							<span>$12.00 – $65.00 </span>
							<a class="add-cart-btn" href="/cart">Add To Cart</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 filtr-item" data-category="4, 1, 2" data-sort="Busy streets">
					<div class="or-trending-product-item text-center">
						<div class="or-trend-item-img position-relative">
							<img src="<?php echo e(asset('assets/img/product/tp6.png')); ?>" alt="">
							<div class="e-commerce-btn">
								<a href="/cart"><i class="fal fa-shopping-cart"></i></a>
								<a href="/product"><i class="fal fa-eye"></i></a>
							</div>
						</div>
						<div class="or-trend-item-text headline-2">
							<h3><a href="/product">Organic Cabbage</a></h3>
							<span>$12.00 – $65.00 </span>
							<a class="add-cart-btn" href="/cart">Add To Cart</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 filtr-item" data-category="1, 3, 4" data-sort="Busy streets">
					<div class="or-trending-product-item text-center">
						<div class="or-trend-item-img position-relative">
							<img src="<?php echo e(asset('assets/img/product/tp7.png')); ?>" alt="">
							<div class="e-commerce-btn">
								<a href="/cart"><i class="fal fa-shopping-cart"></i></a>
								<a href="/product"><i class="fal fa-eye"></i></a>
							</div>
						</div>
						<div class="or-trend-item-text headline-2">
							<h3><a href="/product">Organic Potato</a></h3>
							<span>$12.00 – $65.00 </span>
							<a class="add-cart-btn" href="/cart">Add To Cart</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 filtr-item" data-category="1, 3, 5" data-sort="Busy streets">
					<div class="or-trending-product-item text-center">
						<div class="or-trend-item-img position-relative">
							<img src="<?php echo e(asset('assets/img/product/tp8.png')); ?>" alt="">
							<div class="e-commerce-btn">
								<a href="/cart"><i class="fal fa-shopping-cart"></i></a>
								<a href="/product"><i class="fal fa-eye"></i></a>
							</div>
						</div>
						<div class="or-trend-item-text headline-2">
							<h3><a href="/product">Organic Peas</a></h3>
							<span>$12.00 – $65.00 </span>
							<a class="add-cart-btn" href="/cart">Add To Cart</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('loginscript'); ?>

<script>
    $(document).ready(function() {
        console.log($.session.get('user'))
        if ($.session.get('user')) {
            $('#login').hide();
            $('#register').hide();

        } else {
            $('#profile').hide();
            $('#logout').hide();
            //$('#groceries').hide();
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PP Projects\Selis\Doorstep\resources\views/welcome.blade.php ENDPATH**/ ?>