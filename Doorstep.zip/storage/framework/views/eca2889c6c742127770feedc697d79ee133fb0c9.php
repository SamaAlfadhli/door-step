<?php $__env->startSection('title', 'Door Step | Login'); ?>

<?php $__env->startSection('inner-content'); ?>


<section id="or-login" class="or-login-section" style="background: #76a713">
    <div class="or-login-content sign-login-area d-flex justify-content-center align-items-center">
        <div class="or-login-form">
            <form>
                <input type="email" name="email" placeholder="Your Email" required="">
                <input type="password" name="password" placeholder="Your Password" required="">
                <div class="login-button text-center">
                    
                    <button type="submit" value="Login">Login</button>
                </div>
                <div class="col text-center text-white mt-3 ">
                    <p>Forgot Password? <a href="/resetpassword">Reset Password Here</a></p>
                </div>
            </form>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('loginscript'); ?>

<script>
    $(document).ready(function() {
        console.log($.session.get('user'))
        if ($.session.get('user')) {
            $('#login').hide();
            $('#register').hide();

        } else {
            $('#profile').hide();
            $('#logout').hide();
            //$('#groceries').hide();
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PP Projects\Selis\Doorstep\resources\views/login.blade.php ENDPATH**/ ?>