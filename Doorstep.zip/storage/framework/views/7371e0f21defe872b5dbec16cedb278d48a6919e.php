<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="content">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="Organio - Organic Food Store HTML Templae ">
    <meta name="keywords" content="	farm, food, fresh, fruit, nutrition, organic, organic farm, organic food store, organic shop, organic store, organic theme, store, vegetable, woocommerce">
    <meta name="author" content="Themexriver">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/logo/ficon.png')); ?>" type="image/x-icon">


    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome-all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/video.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.mCustomScrollbar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/rs6.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/zoomit.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick-theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

</head>
<body class="organio-wrapper">
	<div id="preloader"></div>
	<div class="up">
		<a href="#" class="scrollup text-center"><i class="fas fa-chevron-up"></i></a>
	</div>

    <?php echo $__env->make('layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('banner'); ?>

    <?php echo $__env->yieldContent('breadcrumb'); ?>

    <?php echo $__env->yieldContent('inner-content'); ?>


	<section id="or-footer-3" class="or-footer-section-3" data-background="<?php echo e(asset('assets/img/bg/h5-bg-footer1.jpg')); ?>">
		<div class="container">
			<div class="footer-widget-wrapper-3">
				<div class="row">
					<div class="col-lg-4 col-md-6">
						<div class="or-footer-widget headline pera-content ul-li-block">
							<div class="or-logo-widget">
								<a href="#"><img src="<?php echo e(asset('assets/img/logo/logo2.png')); ?> " alt=""></a>
								<p>Bringing Goodness to your Door Step	</p>
								<div class="footer-social">
									<a href="#" tabindex="0"><i class="fab fa-facebook-f"></i></a>
									<a href="#" tabindex="0"><i class="fab fa-twitter"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="or-footer-widget  headline-2 pera-content ul-li-block">
							<div class="or-menu-widget">
								<h2 class="widget-title">Categories</h2>
								<ul>
									<li><a href="/shop-page">Bread & Bakery</a></li>
									<li><a href="/shop-page">Fresh Fruits</a></li>
									<li><a href="/shop-page">Fresh Fish</a></li>
									<li><a href="/shop-page">Fresh Meat</a></li>
									<li><a href="/shop-page">Grocery & Frozen</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="or-footer-widget  headline-2 pera-content ul-li-block">
							<div class="or-menu-widget">
								<h2 class="widget-title">My Account</h2>
								<ul>
									<li><a href="/userprofile" id="profile">My Account</a></li>
									<li><a href="/my-orders">My Orders</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="or-footer-copyright-wrapper">
			<div class="container">
				<div class="or-footer-copyright-wrapper  d-flex justify-content-between align-items-center">
					<div class="or-footer-copyright-3">
						@ Copyright 2022. Door Step
					</div>
					
				</div>
			</div>
		</div>
	</section>




	<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/appear.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/slick.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.counterup.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/waypoints.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.zoomit.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.inputarrow.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/parallax-scroll.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/rbtools.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/rs6.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery.session@1.0.0/jquery.session.min.js"></script>
    <?php echo $__env->yieldContent('loginscript'); ?>
    <?php echo $__env->yieldContent('registerscript'); ?>
    
    <script>
        $(document).ready(function () {
            $('#country-dd').on('change', function () {
                var idCountry = this.value;
                $("#state-dd").html('');
                $.ajax({
                    url: "<?php echo e(url('api/fetch-states')); ?>",
                    type: "POST",
                    data: {
                        country_id: idCountry,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#state-dd').html('<option value="">Select State</option>');
                        $.each(result.states, function (key, value) {
                            $("#state-dd").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                        $('#city-dd').html('<option value="">Select City</option>');
                    }
                });
            });
            $('#state-dd').on('change', function () {
                var idState = this.value;
                $("#city-dd").html('');
                $.ajax({
                    url: "<?php echo e(url('api/fetch-cities')); ?>",
                    type: "POST",
                    data: {
                        state_id: idState,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (res) {
                        $('#city-dd').html('<option value="">Select City</option>');
                        $.each(res.cities, function (key, value) {
                            $("#city-dd").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH D:\PP Projects\Selis\Doorstep\resources\views/layouts/master.blade.php ENDPATH**/ ?>