

<?php $__env->startSection('title', 'Door Step | My Orders'); ?>

<?php $__env->startSection('breadcrumb'); ?>


	<section id="or-breadcrumbs" class="or-breadcrumbs-section position-relative" data-background="<?php echo e(asset('assets/img/bg/bg-page-title.jpg')); ?>">
		<div class="background_overlay"></div>
		<div class="container">
			<div class="or-breadcrumbs-content text-center">
				<div class="page-title headline"><h1>Shop</h1></div>
				<div class="or-breadcrumbs-items ul-li">
					<ul>
						<li><a href="/">Home</a></li>
						<li><a href="/userprofile">User Nmae</a></li>
						<li>My Orders</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('inner-content'); ?>


<section id="or-main-cart" class="or-main-cart-section">
    <div class="container">
        <div class="or-main-cart-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="or-cart-content-table table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="product-name">Order ID</th>
                                    <th class="product-price">Total</th>
                                    <th class="product-subtotal">Track Order</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="product-name" data-title="Product"> 01</td>
                                    <td class="product-price product-subtotal" data-title="Price"> 
                                        <span class=" amount"><bdi><span class="Price-currencySymbol">$</span>4.00</bdi></span>
                                    </td>
                                    <td class="product-subtotal"> 
                                        <a href="/track-order" class="btn custom-door-btn">Track</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="product-name" data-title="Product"> 02</td>
                                    <td class="product-price product-subtotal" data-title="Price"> 
                                        <span class=" amount"><bdi><span class="Price-currencySymbol">$</span>4.00</bdi></span>
                                    </td>
                                    <td class="product-subtotal"> 
                                        <a href="/track-order" class="btn custom-door-btn">Track</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="product-name" data-title="Product"> 03</td>
                                    <td class="product-price product-subtotal" data-title="Price"> 
                                        <span class=" amount"><bdi><span class="Price-currencySymbol">$</span>4.00</bdi></span>
                                    </td>
                                    <td class="product-subtotal"> 
                                        <a href="/track-order" class="btn custom-door-btn">Track</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="product-name" data-title="Product"> 04</td>
                                    <td class="product-price product-subtotal" data-title="Price"> 
                                        <span class=" amount"><bdi><span class="Price-currencySymbol">$</span>4.00</bdi></span>
                                    </td>
                                    <td class="product-subtotal"> 
                                        <a href="/track-order" class="btn custom-door-btn">Track</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PP Projects\Selis\Doorstep\resources\views/my-orders.blade.php ENDPATH**/ ?>