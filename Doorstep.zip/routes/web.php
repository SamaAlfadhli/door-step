<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DropdownController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

session_start();

Route::get('register', [DropdownController::class, 'index']);
Route::get('checkout', [DropdownController::class, 'checkout']);
Route::get('userprofile', [DropdownController::class, 'profile']);
Route::post('api/fetch-states', [DropdownController::class, 'fetchState']);
Route::post('api/fetch-cities', [DropdownController::class, 'fetchCity']);

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', function () {
    return view('login');
});



Route::get('/resetpassword', function () {
    return view('resetpassword');
});
// Route::get('/userprofile', function () {

//     return view('userprofile');
// });

Route::get('/shop-page', function () {

    return view('shop-page');
});

Route::get('/product', function () {

    return view('product');
});

// Route::get('/checkout', function () {

//     return view('checkout');
// });

Route::get('/cart', function () {

    return view('cart');
});

Route::get('/my-orders', function () {

    return view('my-orders');
});

Route::get('/track-order', function () {

    return view('track-order');
});

